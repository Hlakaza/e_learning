import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:pinch_zoom_image/pinch_zoom_image.dart';
import '../ClassArrays/TopicButtonArray.dart';

enum WhyFarther { harder, smarter, selfStarter, tradingCharter }

///defining the variables that will be changed in order to increas text size and activate night mode
var defaultTextColor = Colors.black, defaultBacColor = Colors.white;
var defaultAppBarColor = TopicButtonArray().ColorTheme[0];
var nightModeColorText = Colors.white, nightModeColorBac = Colors.black87;



class Topic2R1 extends StatefulWidget
{
  @override
  _Topic2R1State createState() => _Topic2R1State();
}

class _Topic2R1State extends State<Topic2R1> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    var topicName = TopicButtonArray().TopicTitle[7]; //Topic Name Here
    //var topicName = "Introduction";

    return SafeArea(
      child: ClipRRect(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25.0), topRight: Radius.circular(25.0)),
        child: new Scaffold(
          appBar: new AppBar(
            backgroundColor: defaultAppBarColor,
            elevation: 0.0,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[

                Text("$topicName",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: "NunitoSans-Regular",
                  ),

                ),



              ],

            ),
          ),
          body: new Container(
            color : defaultBacColor,
            child: new ListView(

              children: <Widget>[

                PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-024.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
                PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-025.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 
              ],
            ),
          ),
        ),
      ),
    );


  }
}


class Topic2R2 extends StatefulWidget
{
  @override
  _Topic2R2State createState() => _Topic2R2State();
}

class _Topic2R2State extends State<Topic2R2> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    var topicName = TopicButtonArray().TopicTitle[8]; //Topic Name Here
    //var topicName = "Introduction";

    return SafeArea(
      child: ClipRRect(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(25.0), topRight: Radius.circular(25.0)),
        child: new Scaffold(
          appBar: new AppBar(
            backgroundColor: defaultAppBarColor,
            elevation: 0.0,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[

                Text("$topicName",
                  style: TextStyle(
                    fontSize: 15.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: "NunitoSans-Regular",
                  ),

                ),



              ],

            ),
          ),
          body: new Container(
            color : defaultBacColor,
            child: new ListView(

              children: <Widget>[


                PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-024.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-025.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-026.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-027.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-028.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-029.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-030.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
  
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-031.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-032.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-033.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-034.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-035.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-036.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-037.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-038.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-039.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-040.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-041.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-042.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-043.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-044.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
  
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-045.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-046.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-047.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-048.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-049.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-050.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-051.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-052.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-053.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 PinchZoomImage(image:  CachedNetworkImage(imageUrl: "http://matriclive.com/new_feature/mathematics_lit/textbook/Topic02/topic1/Mathematics_lit-054.jpg",placeholder: (context, url) => new Image.asset("assets/ui_assets/preloader3.gif",),errorWidget: (context, url, error) => new Image.asset("assets/ui_assets/default_error.png",width: 60,height: 60,),),zoomedBackgroundColor: Color.fromRGBO(240, 240, 240, 1.0),hideStatusBarWhileZooming: true,),
 

              ],
            ),
          ),
        ),
      ),
    );


  }
}